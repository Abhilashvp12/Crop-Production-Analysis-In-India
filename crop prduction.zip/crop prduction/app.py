from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__, static_url_path='/static', static_folder='static')


# Load the dataset
df = pd.read_csv('Crop Production data.csv')  # Replace 'your_dataset.csv' with your dataset file path

# Get unique values of States, Districts, and Crops
states = df['State_Name'].unique().tolist()
districts = df['District_Name'].unique().tolist()
crops = df['Crop'].unique().tolist()
seasons = df['Season'].unique().tolist()
area = df['Area'].unique().tolist()

# Load the saved models into memory
model1 = joblib.load('linear_regression.pkl')
model2 = joblib.load('polynomial_regression.pkl')
model3 = joblib.load('ridge_regression.pkl')
model4 = joblib.load('lasso_regression.pkl')
model5 = joblib.load('elastic_net_regression.pkl')

# Define the home route
@app.route('/')
def home():
    return render_template('index.html', states=states, districts=districts, crops=crops, seasons=seasons, area=area)

# Define prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    # Get input data from the request
    data = request.json
    
    # Filter the dataset based on input State, District, and Crop
    filtered_data = df[(df['State_Name'] == data['State_Name']) & 
                       (df['District_Name'] == data['District_Name']) & 
                       (df['Crop'] == data['Crop']) &
                       (df['Season'] == data['Season'])&
                       (df['Area']== data['Area'])]
    
    # Use State_Name, District_Name, and Crop as features for prediction
    features = filtered_data[['State_Name', 'District_Name', 'Crop', 'Season','Area']]

    # Perform predictions using the loaded models
    prediction1 = model1.predict(features)  # Update with your features
    prediction2 = model2.predict(features)
    prediction3 = model3.predict(features)
    prediction4 = model4.predict(features)
    prediction5 = model5.predict(features)

    # Return predictions along with other data as JSON response
    return jsonify({
        'state': data['State_Name'],
        'district': data['District_Name'],
        'crop': data['Crop'],
        'season': data['Season'],
        'area': data['Area'],
        'prediction1': prediction1.tolist(),
        'prediction2': prediction2.tolist(),
        'prediction3': prediction3.tolist(),
        'prediction4': prediction4.tolist(),
        'prediction5': prediction5.tolist()
    })

if __name__ == '__main__':
    app.run(debug=True)